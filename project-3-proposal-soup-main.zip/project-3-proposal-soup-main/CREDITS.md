Tejas Hiremath: Research Q
Devang Jagdale: Tools and Tech
Chaitanya Jha:  Analysis.